<?php
/*
Plugin Name: Sistema de Asistencia Inteligente
Plugin URI: http://plugin-sai.sidevtech.com/
Description: Plugin que permite crear un asistente virtual en aplicaciones hechas en WordPress.
Version: 1.0
Author: Carlos Andres Arevalo Cortes
Author URI: https://carlosandresarevalo.com/
License: GPL2
*/

// Registra una función para crear el menú de administración
function sai_admin_menu() {
  add_menu_page(
      'sai',      // Título de la página
      'Asistente Virtual',      // Título del menú
      'manage_options',     // Capacidad requerida para acceder
      'sai',      // ID del menú
      'sai_admin_page',  // Función que renderiza la página de administración
      'dashicons-admin-generic',   // Icono del menú (opcional)
      99                      // Posición del menú en el panel
  );
}
add_action( 'admin_menu', 'sai_admin_menu' );

// Función que renderiza la página de administración
function sai_admin_page() {
  global $wpdb;

  // Verifica si se ha enviado el formulario
  if (isset($_POST['submit'])) {
    // Obtén el token enviado por el formulario
    $token = sanitize_text_field($_POST['token']);
    $id = sanitize_text_field($_POST['id']);

    $value = [
      "id" => $id,
      "token" => $token,
    ];

    // Guarda o actualiza el token en la tabla de WordPress
    $table_name = $wpdb->prefix . 'config_sai'; // Reemplaza 'config_sai' con el nombre de tu tabla
    $key = 'configKey';
    $existing_token = $wpdb->get_var($wpdb->prepare("SELECT value_data FROM $table_name WHERE key_data = %s", $key));

    if ($existing_token) {
      // Si key_data ya existe, actualiza el registro
      $wpdb->update(
        $table_name,
        array('value_data' => json_encode($value)),
        array('key_data' => $key),
        array('%s'), // Tipo de dato: cadena de texto (string)
        array('%s') // Tipo de dato: cadena de texto (string)
      );
    } else {
      // Si key_data no existe, inserta un nuevo registro
      $wpdb->insert(
        $table_name,
        array(
          'key_data' => $key,
          'value_data' => json_encode($value),
        ),
        array('%s', '%s') // Tipos de datos: cadena de texto (string), cadena de texto (string)
      );
    }

    // Muestra un mensaje de éxito
    echo '<div class="notice notice-success"><p>El token ha sido guardado correctamente.</p></div>';
  }

  // Obtén el token existente de la tabla de WordPress
  $table_name = $wpdb->prefix . 'config_sai'; // Reemplaza 'config_sai' con el nombre de tu tabla
  $existing_token = $wpdb->get_var($wpdb->prepare("SELECT value_data FROM $table_name WHERE key_data = %s", 'configKey'));
  $token = json_decode($existing_token)->token ?? null; //
  $id = json_decode($existing_token)->id ?? null; 

  // Muestra el contenido de la página de administración con el formulario
  echo '
    <div class="wrap">
      <h1>Activación de asistente inteligente</h1>
      <p>Ingrese el token de activación:</p>
      <form method="post" action="">
        <input type="text" name="id" placeholder="ID del usuario" value="' . esc_attr($id) . '"  required>
        <input type="text" name="token" placeholder="Token" value="' . esc_attr($token) . '" required>
        <input type="submit" name="submit" value="Guardar">
      </form>
    </div>
  ';
}



function sai_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'config_sai'; // Reemplaza 'nombre_de_la_tabla' con el nombre que desees para tu tabla

    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        key_data VARCHAR(255) NOT NULL,
        value_data JSON NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

function sai_save_auth(){
  global $wpdb;
  $table_name = $wpdb->prefix . 'config_sai'; 
  $token = [
    "authAccess" => "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiwianRpIjoiZmFmMGQzMmQyNTlmYzExMzQwN2YzZGE2Mjc1ZjIwNmY2NTU4MDI5ODk3MDY1NDg1OTc2ODdkMTIyMDQyZjk1ZTQ5OGY5OGYyMGVlNzVhNTUiLCJpYXQiOjE2ODkzMDY1MjcuODcxMzU5LCJuYmYiOjE2ODkzMDY1MjcuODcxMzYzLCJleHAiOjQ4NDQ5ODAxMjcuODUzNzkzLCJzdWIiOiIiLCJzY29wZXMiOltdfQ.LqG_k-UoYGW_kgUViA88EOEIcqKsJ-rdmgPbvJJdmdfye6yOC5YMrl-v8WhyKC3MKYeHPg9YYsfijsW6WHvQ9Cnz5tWV5d8H51kQ6MS5ogcERFuPyDn5hkE4WkMcj-_fwf5dNKYj_Yz8BpbFr-JxoZ-sGep3-Vy7leM6CLh5gK6lVeo6MWj3E_hcKEAsAuz4lzwscnHrPH5dqZ7JGhxsrg3CVrVcgVJDFqg1Noa6LfVf-zOQ_9Fp8WWIsMOXdA9QkcU7JW3_-NtEEOBJJ02iufLNCxX1pZ0EROHx38fX3TcIzJ24luaw1q9MBpfXo5sZXUxiSE-UvOaUmSzBzvRpv0nhPNtLUQpkwH962DLo3QIKXsx9KvF-tgtHqunIEaijDemB-y88MqZ2d9t7lJUY_kEb_0vCZ7IJHIaSjKxBJSLhwDSyRDRbgTd8xexGjCrYe6z8OslipnRMIXhP2PEHMs_m0zej9SFzSp_8nlA3iTzYOwRJFq4SozSp7mivujJB7co7hpfbPDQ88VGBHKfcmvN8vvJSGvN44iz91Fuz7Yy9OVQeuygNjE47HX-WRjSA7y_lOdtBLKhcR4KV6HzMPR1NYmiwrczCcJGwbXzuntFCocAnrEYrTRLy0_i59O6CrLRB0V9gXbexyiKtKFPpIB8KU0xf1JUImjqCyQHcliU"
  ];
  $wpdb->insert(
    $table_name,
    array(
      'key_data' => 'auth',
      'value_data' => json_encode($token),
    ),
    array('%s', '%s') // Tipos de datos: cadena de texto (string), cadena de texto (string)
  );
}

function sai_get_data_config($key){
  global $wpdb;
  $table_name = $wpdb->prefix . 'config_sai'; 

  $result = $wpdb->get_results( "SELECT * FROM $table_name WHERE `key_data` = '$key'");

  return $result;
}


function sai_plugin_activation() {
    sai_create_table();
    sai_save_auth();
}
register_activation_hook( __FILE__, 'sai_plugin_activation' );

function sai_plugin_deactivation() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'config_sai'; // Reemplaza 'nombre_de_la_tabla' con el nombre que utilizaste para tu tabla

    $sql = "DROP TABLE IF EXISTS $table_name;";
    $wpdb->query( $sql );
}
register_deactivation_hook( __FILE__, 'sai_plugin_deactivation' );

function sai_shortcode() {
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
     
      $args = array(
          'post_type' => 'product',
          'posts_per_page' => -1,
      );
      
      $products = get_posts($args);

      // Procesar los productos y guardarlos en un objeto
      $productData = array();
      foreach ($products as $product) {
          $productId = $product->ID;
          $productName = $product->post_title;
          $productPrice = get_post_meta($productId, '_regular_price', true);

          // Guardar los datos del producto en el objeto
          $productData[] = array(
            'id' => $productId,
            'name' => $productName,
            'price' => $productPrice,
            'excerpt' => $product->post_excerpt,
            'permalink' => $product->guid,
            // Agrega más propiedades según tus necesidades
        );
      }

      $productsTotal = json_encode($productData, JSON_UNESCAPED_SLASHES | JSON_HEX_APOS);

    }else{
      $productsTotal = null;
    }


    wp_enqueue_style( 'shortcode-style', plugin_dir_url( __FILE__ ) . 'css/shortcode.css', array(), '1.0' );
    $token_results = sai_get_data_config('configKey');
    $auth = sai_get_data_config('auth');
    $value = json_decode($token_results[0]->value_data);
    $valueAuth = json_decode($auth[0]->value_data);
    $token = '';
    if (!empty($token_results)) {
        $token = $value->token;
        $id = $value->id;
        $bearerToken = $valueAuth->authAccess;
        
    }
    
    ob_start();
    ?>
    <div id="sai">
        <div v-if="showMessage" class="floating-message" @click="handleButtonClick">
            <img src="<?php echo plugin_dir_url( __FILE__ ) . 'assets/sai.png'; ?>" style="width: 100%; height: 100%; border-radius: 50%;" alt="Logo de nuestro asistente virtual" srcset="">     
        </div>
        <div v-if="chatOpen" class="chat-container">
            <div class="chat-header">
                <span>Sistema de Asistencia Inteligente (SAI)</span>
                <button class="close-button" @click="closeChat">Cerrar Chat</button>
            </div>
            <div class="chat-messages">
                <div
                v-for="message in messages"
                class="chat-message"
                :key="message.id"
                :class="{'chat-message-bot': message.sender === 'bot', 'chat-message-user': message.sender === 'user'}"
                >
                <img :src="message.sender == 'bot' ? imageSai : imageUser" alt="">
                <p class="chat-message-text" v-html="decodeEntities(message.content)"></p>
                </div>
                <div class="chat-message" v-show="consult">
                <img :src="imageSai" alt="">
                <div class="progress-circular">
                  <div class="progress-circular-inner"></div>
                </div>
                <p class="chat-message-text">Procesando .....</p>
                </div>
            </div>
            <div class="chat-input-container">
                <input v-model="inputMessage" class="chat-input" placeholder="Escribe un mensaje" @keyup.enter="sendMessage">
                <button class="chat-send-button" @click="sendMessage">Enviar</button>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>

    <script>

    const format = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false, timeZone: 'America/Bogota' };

    new Vue({
        el: '#sai',
        data: {
            showMessage: true,
            imageUser: '<?php echo plugin_dir_url( __FILE__ ) . "assets/SaiCloud.svg"; ?>',
            imageSai: '<?php echo plugin_dir_url( __FILE__ ) . "assets/sai.png"; ?>',
            chatOpen: false,
            inputMessage:'',
            messages: [],
            consult: false,
        },
        mounted() {
          window.addEventListener('scroll', this.handleScroll);
          window.addEventListener('resize', this.handleResize);
        },
        beforeUnmount() {
          window.removeEventListener('scroll', this.handleScroll);
          window.removeEventListener('resize', this.handleResize);
        },
        methods:{
          decodeEntities(value) {
            const textarea = document.createElement('textarea');
            textarea.innerHTML = value;
            return textarea.value;
          },
          handleScroll() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            this.containerStyle.bottom = scrollTop > 0 ? '20px' : '100px';
          },
          handleResize() {
            const screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            if (screenWidth < 600) {
              this.containerStyle.width = '60px';
              this.containerStyle.height = '60px';
            } else {
              this.containerStyle.width = '80px';
              this.containerStyle.height = '80px';
            }
          },
            handleButtonClick(){
                this.chatOpen = !this.chatOpen;
            },
            closeChat() {
                this.chatOpen = false;
            },
            sendMessage() {
              const message = this.inputMessage.trim();
                if (message !== '') {
                  
                    this.messages.push({ id: Date.now(), sender: 'user', content: message , activeComponent:false, component: '' });
                    // Lógica para procesar la respuesta del chatbot
                    this.inputMessage = '';

                    this.$nextTick(() => {
                      const chatBody = document.querySelector('.chat-messages');
                      chatBody.scrollTop = chatBody.scrollHeight;
                    });

                    this.sendServices(message);

                    
                }
            },
            sendServices(message){
              this.consult = true;
              const token = '<?php echo $token; ?>';
              const id = '<?php echo $id; ?>';
              const auth = '<?php echo $bearerToken; ?>';
              const products = '<?php echo $productsTotal; ?>';
              
              const urlBase = 'http://sai-back.test/';
              if(token !== ''){
                axios.post(urlBase + 'api/sai/send/'+ id, {
                message: message,
                products: products,
                token: token
                }, {headers: {
                    Authorization: 'Bearer '+ auth,
                  },})
                  .then(response => {
                  console.log(response);

                  this.consult = false;
                  // Agregar la respuesta del servidor al chat
                  this.addMessage({
                    id:1,
                    sender: 'bot',
                    content: response.data.message,
                    link: '',
                    activeComponent: response.data.activeComponent ?? false,
                    component: response.data.component ?? null,
                    timestamp: new Date().toLocaleTimeString('es-ES',format)
                  });

                })
                .catch(error => {
                  console.log(error);
                  this.addMessage({
                    id:1,
                    sender: 'bot',
                    content: "El token de activación que ingresaste no es valido.",
                    link: '',
                    activeComponent:false,
                    component:null,
                    timestamp: new Date().toLocaleTimeString('es-ES',format)
                  });
                  this.consult = false;
                });
              }else{
                this.addMessage({
                    id:1,
                    sender: 'bot',
                    content: "El asistente no esta activo, ingresa un token de activación valido",
                    link: '',
                    activeComponent:false,
                    component:null,
                    timestamp: new Date().toLocaleTimeString('es-ES',format)
                });

                this.consult = false;
              }
             
            },
            addMessage(message) {
                this.messages.push(message);
                // Desplazarse al final del chat para mostrar el último mensaje
                this.$nextTick(() => {
                    const chatBody = document.querySelector('.chat-messages');
                    chatBody.scrollTop = chatBody.scrollHeight;
                });
            },
        }
    });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode( 'sai', 'sai_shortcode' );

// Encola los archivos de Bootstrap
function sai_admin_enqueue_scripts() {
    // Encola el archivo CSS de Bootstrap
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css', array(), '5.0.2' );

    // Encola el archivo de script de Bootstrap (requiere jQuery)
    wp_enqueue_script( 'jquery' ); // Asegúrate de que jQuery esté registrado y encolado antes que el archivo de Bootstrap
    wp_enqueue_script( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js', array( 'jquery' ), '5.0.2', true );

    // // Encola el archivo de script que contiene tu componente Vue.js
    // wp_enqueue_script( 'sai-script', plugin_dir_url( __FILE__ ) . 'js/sai.js', array( 'vue' ), '1.0', true );

    // // Encola los estilos CSS necesarios para tu componente Vue.js
    // wp_enqueue_style( 'sai-style', plugin_dir_url( __FILE__ ) . 'css/sai.css', array( 'bootstrap' ), '1.0' );
}
add_action( 'admin_enqueue_scripts', 'sai_admin_enqueue_scripts' );
